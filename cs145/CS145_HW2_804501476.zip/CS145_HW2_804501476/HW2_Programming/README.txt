Libraries required:
* sklearn
* numpy
* matplotlib

Data:
* File: iris.data
* The dataset has 150 data points, 4 features, and 3 class labels. Each fold of 5-fold cross validation will have 120 training points, and 30 test points.

Code File:
* KNN.py

How to Run:
* Fill in the missing lines of code
* Run KNN.py